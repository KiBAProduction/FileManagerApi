class Aventurier{
    constructor(name, race, classe){
        this.name = name;
        this.race = race;
        this.classe = classe;
    }
}