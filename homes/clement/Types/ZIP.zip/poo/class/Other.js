export const data = [1,2,3,4];

export function foo(){
    return `Other::foo()`;
}