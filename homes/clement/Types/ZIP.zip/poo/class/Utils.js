function foo(){
    return `utils::foo()`;
}

const data = ['foo', 'bar', 'baz'];
const m = ['Jan', 'Fev', 'Mar'];

export {foo, data, m as month};

export function loaded(callable){
    window.addEventListener('DOMContentLoaded', callable);
}

// "remplacer" l'appel document.querySelector par "s"
export function s(selector){
    return document.querySelector(selector);
}

// "remplacer" l'appel document.querySelectorAll par "sAll"
export function sAll(selector){
    return document.querySelectorAll(selector);
}

export function loadNav(){
    fetch('../includes/navigation.html')
        .then(function(response){
            return response.text();
        }).then(function(nav){
            s('body > nav').innerHTML = nav;
        });
}

export function cE(element){
    return document.createElement(element);
}

export function print(selector, value, html = false){
    let target = s(selector);
    (html)?target.innerHTML = value : target.textContent = value;
}