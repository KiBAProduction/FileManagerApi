import {foo, data, month, loaded, s, sAll, loadNav, cE, print} from './Utils.js';
import * as other from './Other.js';
import {Admin, User} from './User.js';
import Company, {Employee} from './Company.js';

console.log(foo());
console.log(data);
for(let value of month){
    console.log(value);
}

console.log(other);
console.log(other.foo());
for(let value of other.data){
    console.log(value);
}

let user = new User('Jon Sno');

console.log(`Hello ${user.name}`);

let admin = new Admin('Arya Stark');

console.log(`Hello ${admin.name}, ${admin.role}`);

let company = new Company('Agence tous risques');

let agent = new User('Mr T')

console.log(`Company name : ${company.name} avec l'agent ${agent.name}`);

let soldat = new Employee('Striker', 'Colonel');

console.log(`Company name : ${company.name} avec l'agent ${soldat.name}, ${soldat.job}`);

loaded(function(){
    loadNav();
    //console.log('test');
    s('#testModule').addEventListener('click', function(){
        console.log('Le module à l\'air de fonctionner');
    });
});