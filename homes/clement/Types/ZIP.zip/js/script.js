console.log('script extérieur chargé en début de chargement de lapage');

function loaded(callable){
    window.addEventListener('DOMContentLoaded', callable);
}

// "remplacer" l'appel document.querySelector par "s"
function s(selector){
    return document.querySelector(selector);
}

// "remplacer" l'appel document.querySelectorAll par "sAll"
function sAll(selector){
    return document.querySelectorAll(selector);
}

function loadNav(){
    fetch('../includes/navigation.html')
        .then(function(response){
            return response.text();
        }).then(function(nav){
            s('body > nav').innerHTML = nav;
        });
}

function cE(element){
    return document.createElement(element);
}

function print(selector, value, html = false){
    let target = s(selector);
    (html)?target.innerHTML = value : target.textContent = value;
}

function getXhr(){
    let xhr = null;
    if( window.XMLHttpRequest || window.ActiveXObject ){ //le navigateur supporte-t'il AJAX
        if(window.ActiveXObject){ // est-ce un IE ?
            try{
                xhr = new ActiveXObject('Msxml2.XMLHTTP'); // test protocole 1 pour IE
            }catch(e){
                xhr = new ActiveXObject('Microsoft.XMLHTTP'); // si protocole 1 échoue, utilise l'autre protocole
            }
        }else{ // tout sauf IE
            xhr = new XMLHttpRequest; // utilise le protocole normal XMLHttpRequest
        }
    }else{ // navigateur ne supporte pas xhr
        console.log(`Votre navigateur ne supporte pas AJAX)`);
        xhr = false;
    }
    return xhr; // renvoie du résultat de la connexion
}